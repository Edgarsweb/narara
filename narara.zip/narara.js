// const toggleButton = document.getElementsByClassName('toggle-button')[0]
// const navbarLinks = document.getElementsByClassName('navbar-links')[0]

// toggleButton.addEventListener('click', ()=> {
//     navbarLinks.classList.toggle('active')
// })

// var i = 0;
// var txt = 'Hi, Welcome to my Portfolio Website';
// var speed = 100;

// function typeEffect() {
//   if (i < txt.length) {
//     document.getElementById("type").innerHTML += txt.charAt(i);
//     i++;
//     setTimeout(typeEffect, speed);
//   }
// }

// function toggle() {
//     var curtain = document.getElementById('curtain');
//     curtain.classList.toggle('active')
//   }






function toggle() {
  var curtain = document.getElementById('curtain');
  curtain.classList.toggle('active');
 
}




var wrapperMenu = document.getElementById('wrapper-menu');
var menuClose = document.getElementById('list');

wrapperMenu.addEventListener('click', function(){
wrapperMenu.classList.toggle('open');

})

menuClose.addEventListener('click', function(){
  curtain.classList.toggle('active');
  wrapperMenu.classList.toggle('open');
  
  })




var arr = document.getElementById('arrow');

// if ( wrapperMenu.style.display = 'none') {
//   arr.style.display = 'block';
// }






